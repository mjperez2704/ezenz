import Image from "next/image"

export function AnaquelesBóticasSection() {
  return (
    <section className="relative w-full bg-white">
      {/* ANAQUELES Section */}
      <div className="relative w-full h-[1080px] md:h-[1080px]">
        <Image
          src="fondos/anaqueles_botica.jpg"
          alt="Anaqueles background"
          fill
          className="object-cover"
          quality={100}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-transparent" />

        <div className="max-w-7xl px-6 sm:px-8 lg:px-[0] text-right mx-[400px] w-[1200px] h-[400px] my-0          <div className="max-w-7xl px-6 sm:px-8 lg:px-[0] text-right mx-[400px] w-[1200px] h-[400px] my-0         <div className="max-w-3xl ml-auto text-center">
              <h2 className="text-4xl font-light text-white mb-8 tracking-[0.3em] text-center md:text-4xl">
                ANAQUELES
              </h2>

              <p className="text-lg md:text-xl text-white mb-12 text-center">
                Contamos con bodegas principales destinadas a:
              </p>

              {/* Timeline */}
              <div className="flex flex-col md:flex-row items-start justify-end md:gap-[100] text-center md:items-stretch">
                {/* Item 1 */}
                <div className="flex items-end flex-col">
                  <div className="w-4 h-4 rounded-full bg-white mb-4" />
                  <p className="text-white text-base md:text-lg font-medium text-center">Materias primas</p>
                </div>

                {/* Connecting line */}
                <div className="hidden md:block h-px bg-white w-72" />

                {/* Item 2 */}
                <div className="flex flex-col items-end text-center">
                  <div className="w-4 h-4 rounded-full bg-white mb-4" />
                  <p className="text-white text-base md:text-lg font-medium text-center">Material de empaque</p>
                </div>

                {/* Connecting line */}
                <div className="hidden md:block h-px bg-white w-72" />

                {/* Item 3 */}
                <div className="flex flex-col items-end">
                  <div className="w-4 h-4 rounded-full bg-white mb-4" />
                  <p className="text-white text-base font-medium max-w-[200px] text-center md:text-base">
                    Insumos y activos líquidos o en polvo
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-16">
            <div className="grid md:grid-cols-2 gap-12 md:gap-16 items-center">
              {/* Left Content */}

              {/* Right Image */}
            </div>
          </div>
        </div>
      </div>

      {/* BÓTICA Section */}
      <div className="relative w-full bg-white py-8 md:py-12">
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-16">
          <div className="grid md:grid-cols-2 gap-12 md:gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-light text-black tracking-[0.2em]">BÓTICA</h2>

              <p className="text-base md:text-lg text-gray-700 leading-relaxed">
                Nuevo proyecto con modelo escalable y visión a futuro, diseñado para evolucionar hacia un formato de
                franquicia.
              </p>

              {/* Timeline Items - Horizontal Layout */}
              <div className="flex items-start gap-8 md:gap-12">
                {/* Item 1 */}
                <div className="flex flex-col items-center flex-1">
                  <div className="w-3 h-3 rounded-full bg-black mb-3" />
                  <div className="h-px w-full bg-black mb-3" />
                  <p className="text-black text-sm md:text-base font-medium text-center">Call Center</p>
                </div>

                {/* Item 2 */}
                <div className="flex flex-col items-center flex-1">
                  <div className="w-3 h-3 rounded-full bg-black mb-3" />
                  <div className="h-px w-full bg-black mb-3" />
                  <p className="text-black text-sm md:text-base font-medium text-center">
                    Showroom de material de empaque primario y secundario.
                  </p>
                </div>

                {/* Item 3 */}
                <div className="flex flex-col items-center flex-1">
                  <div className="w-3 h-3 rounded-full bg-black mb-3" />
                  <div className="h-px w-full bg-black mb-3" />
                  <p className="text-black text-sm md:text-base font-medium text-center">
                    Catálogo digital de materias primas y productos terminados
                  </p>
                </div>
              </div>
            </div>

            {/* Right Image */}
          </div>
        </div>
      </div>
    </section>
  )
}
